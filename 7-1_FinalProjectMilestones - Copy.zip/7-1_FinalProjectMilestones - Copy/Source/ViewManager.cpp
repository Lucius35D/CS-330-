///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;
	// Camera travel speed in units per second.
	float gMovementSpeed = 4.0f;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);

	// Narrow the field of view for a closer view of the notebook
	g_pCamera->Zoom = 45;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window, double xMousePos, double yMousePos)
{
	if (g_pCamera == nullptr)
	{
		return;
	}
	const float mouseX = static_cast<float>(xMousePos);
	const float mouseY = static_cast<float>(yMousePos);

	// Prevent a sudden camera jump on the first mouse event.
	if (gFirstMouse)
	{
		gLastX = mouseX;
		gLastY = mouseY;
		gFirstMouse = false;
		return;
	}

	const float sensitivity = 0.10f;
	const float xOffset = (mouseX - gLastX) * sensitivity;
	const float yOffset = (gLastY - mouseY) * sensitivity;

	gLastX = mouseX;
	gLastY = mouseY;

	// Start from the camera's current direction.
	const glm::vec3 front = glm::normalize(g_pCamera->Front);
	float yaw = glm::degrees(glm::atan(front.z, front.x));
	float pitch = glm::degrees(
		glm::asin(glm::clamp(front.y, -1.0f, 1.0f)));

	yaw += xOffset;

	// Limit vertical rotation to prevent the camera from flipping.
	pitch = glm::clamp(pitch + yOffset, -89.0f, 89.0f);

	const float yawRadians = glm::radians(yaw);
	const float pitchRadians = glm::radians(pitch);

	glm::vec3 direction;
	direction.x = glm::cos(yawRadians) * glm::cos(pitchRadians);
	direction.y = glm::sin(pitchRadians);
	direction.z = glm::sin(yawRadians) * glm::cos(pitchRadians);

	g_pCamera->Front = glm::normalize(direction);

	// Keep the camera upright as its viewing direction changes.
	const glm::vec3 worldUp(0.0f, 1.0f, 0.0f);
	const glm::vec3 right = glm::normalize(
		glm::cross(g_pCamera->Front, worldUp));
	g_pCamera->Up = glm::normalize(
		glm::cross(right, g_pCamera->Front));
}
// Adjust camera travel speed with the mouse wheel.
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	gMovementSpeed += static_cast<float>(yOffset) * 0.5f;

	// Keep movement controllable and prevent zero or negative speed.
	gMovementSpeed = glm::clamp(gMovementSpeed, 0.5f, 20.0f);
}
/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Close the window with Escape.
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
		return;
	}
	// Select perspective view with P.
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// Select orthographic view with O.
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}
	
	// Determine forward, right, and vertical movement directions.
	const glm::vec3 worldUp(0.0f, 1.0f, 0.0f);
	const glm::vec3 forward = glm::normalize(g_pCamera->Front);
	const glm::vec3 right = glm::normalize(
		glm::cross(forward, worldUp));

	glm::vec3 movement(0.0f);

	// Forward and backward.
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		movement += forward;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		movement -= forward;
	}

	// Left and right.
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		movement -= right;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		movement += right;
	}

	// Up and down.
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		movement += worldUp;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		movement -= worldUp;
	}

	// Maintain consistent speed, including diagonal movement.
	if (glm::dot(movement, movement) > 0.0001f)
	{
		const float frameTime = glm::clamp(gDeltaTime, 0.0f, 0.1f);
		g_pCamera->Position +=
			glm::normalize(movement) * gMovementSpeed * frameTime;
	}
}


/***********************************************************
 * PrepareSceneView()
 *
 * Updates camera movement, view matrix, and projection.
 * P selects perspective and O selects orthographic.
 * Both modes preserve the current camera orientation.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	// Calculate elapsed time between frames.
	float currentFrame = static_cast<float>(glfwGetTime());
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// Handle keyboard input.
	ProcessKeyboardEvents();

	// Calculate the window aspect ratio.
	const float aspectRatio =
		static_cast<float>(WINDOW_WIDTH) /
		static_cast<float>(WINDOW_HEIGHT);

	// Use the same camera for both projection modes.
	glm::mat4 view = g_pCamera->GetViewMatrix();

	glm::mat4 projection;

	if (bOrthographicProjection)
	{
		// Orthographic projection without moving the camera.
		const float halfHeight = 6.0f;

		projection = glm::ortho(
			-halfHeight * aspectRatio,
			halfHeight * aspectRatio,
			-halfHeight,
			halfHeight,
			0.1f,
			100.0f);
	}
	else
	{
		// Perspective projection with the current camera.
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			aspectRatio,
			0.1f,
			100.0f);
	}

	// Send camera information to the shaders.
	if (m_pShaderManager != NULL)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName, view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName, projection);

		m_pShaderManager->setVec3Value(
			"viewPosition", g_pCamera->Position);
	}
}
