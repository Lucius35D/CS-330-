///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// Free the loaded OpenGL textures
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
 /***********************************************************
  * DefineObjectMaterials()
  *
  * Defines how each notebook material reacts to the lights.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Wood desk material
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.35f, 0.25f, 0.15f);
	woodMaterial.ambientStrength = 0.20f;
	woodMaterial.diffuseColor = glm::vec3(0.45f, 0.30f, 0.18f);
	woodMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	woodMaterial.shininess = 4.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// Matte paper material
	OBJECT_MATERIAL paperMaterial;
	paperMaterial.ambientColor = glm::vec3(0.43f, 0.43f, 0.43f);
	paperMaterial.ambientStrength = 0.21f;
	paperMaterial.diffuseColor = glm::vec3(0.61f, 0.61f, 0.61f);
	paperMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	paperMaterial.shininess = 3.0f;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);

	// Notebook cover material
	OBJECT_MATERIAL coverMaterial;
	coverMaterial.ambientColor = glm::vec3(0.20f, 0.20f, 0.20f);
	coverMaterial.ambientStrength = 0.20f;
	coverMaterial.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f);
	coverMaterial.specularColor = glm::vec3(0.18f, 0.18f, 0.18f);
	coverMaterial.shininess = 10.0f;
	coverMaterial.tag = "cover";
	m_objectMaterials.push_back(coverMaterial);

	// Metal material for the spiral rings
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	metalMaterial.ambientStrength = 0.20f;
	metalMaterial.diffuseColor = glm::vec3(0.30f, 0.30f, 0.30f);
	metalMaterial.specularColor = glm::vec3(0.65f, 0.65f, 0.65f);
	metalMaterial.shininess = 40.0f;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);
}
/***********************************************************
 * SetupSceneLights()
 *
 * Adds two light sources so the notebook and desk remain
 * clearly visible with no areas in complete shadow.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable Phong lighting
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// Main white light from above and to the right
	m_pShaderManager->setVec3Value(
		"lightSources[0].position",
		5.0f, 8.0f, 5.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor",
		0.02f, 0.02f, 0.02f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor",
		0.22f, 0.22f, 0.22f);

	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor",
		0.18f, 0.18f, 0.18f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength",
		32.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity",
		0.30f);
	// Secondary blue light from the opposite side
	m_pShaderManager->setVec3Value(
		"lightSources[1].position",
		-5.0f, 4.0f, -3.0f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor",
		0.00f, 0.08f, 0.25f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor",
		0.05f, 0.50f, 1.00f);

	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor",
		0.05f, 0.45f, 1.00f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength",
		30.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity",
		0.90f);
}
void SceneManager::PrepareScene()
{
	// Load textures used throughout the notebook scene
	CreateGLTexture("textures\\desk.jpg", "desk");
	CreateGLTexture("textures\\leather.jpg", "leather");
	CreateGLTexture("textures\\paper.jpg", "paper");
	CreateGLTexture("textures\\metal.jpg", "metal");

	// Bind the loaded textures to OpenGL texture slots
	BindGLTextures();

	// Define the materials used in the notebook scene
	DefineObjectMaterials();

	// Configure the lighting for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// Load the meshes required for the floor and notebook.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();

	// Additional primitive shapes for pencil and coffee mug
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply and tile the wood texture across the desktop surface
	SetShaderTexture("desk");
	SetShaderMaterial("wood");
	SetTextureUVScale(4.0f, 4.0f);

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();


	/***************************************************************
 * NOTEBOOK COVER
 * A thin box forms the tan cover underneath the notebook pages.
 * The cover is scaled, rotated, and translated to match the
 * diagonal orientation of the notebook in the reference image.
 ***************************************************************/

 // Scale the box into a thin rectangular notebook cover
	scaleXYZ = glm::vec3(4.5f, 0.20f, 6.0f);

	// Rotate the notebook diagonally on the floor
	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f;
	ZrotationDegrees = 0.0f;

	// Position the notebook slightly above the floor
	positionXYZ = glm::vec3(1.0f, 0.20f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply leather texture to the notebook cover
	SetShaderTexture("leather");
	SetShaderMaterial("cover");
	SetTextureUVScale(2.0f, 2.0f);

	// Draw the notebook cover
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************
 * NOTEBOOK PAGES
 * A second thin box creates the white pages on top of the
 * notebook cover. It uses the same rotation as the cover.
 ***************************************************************/

 // Scale the pages slightly smaller than the cover
	scaleXYZ = glm::vec3(4.1f, 0.25f, 5.6f);

	// Match the diagonal rotation of the notebook cover
	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f;
	ZrotationDegrees = 0.0f;

	// Raise the pages slightly above the cover
	positionXYZ = glm::vec3(1.0f, 0.42f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply paper texture to the notebook pages
	SetShaderTexture("paper");
	SetShaderMaterial("paper");
	SetTextureUVScale(2.0f, 2.0f);

	// Draw the notebook pages
	m_basicMeshes->DrawBoxMesh();

	/***************************************************************
 * NOTEBOOK SPIRAL BINDING
 * Multiple torus meshes create the dark binding rings across
 * the top edge of the notebook. Each ring overlaps the page
 * edge to create the appearance of a spiral-bound notebook.
 ***************************************************************/

 // Scale the rings to fit the notebook binding.
	scaleXYZ = glm::vec3(0.22f, 0.22f, 0.22f);

	// Rotate the rings so they stand over the page edge
	// while following the notebook's diagonal orientation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = -15.0f;
	ZrotationDegrees = 90.0f;

	// Apply metal texture to the spiral binding rings
	SetShaderTexture("metal");
	SetShaderMaterial("metal");
	SetTextureUVScale(2.0f, 2.0f);

	// First binding ring
	positionXYZ = glm::vec3(-0.10f, 0.62f, -2.25f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();


	// Second binding ring
	positionXYZ = glm::vec3(0.45f, 0.62f, -2.15f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();


	// Third binding ring
	positionXYZ = glm::vec3(1.00f, 0.62f, -1.95f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();


	// Fourth binding ring
	positionXYZ = glm::vec3(1.55f, 0.62f, -1.80f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();

	// Fifth binding ring
	positionXYZ = glm::vec3(2.10f, 0.62f, -1.65f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();


	// Sixth binding ring
	positionXYZ = glm::vec3(2.65f, 0.62f, -1.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();

	// Seventh binding ring
	positionXYZ = glm::vec3(3.20f, 0.62f, -1.40f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	m_basicMeshes->DrawTorusMesh();




	/***********************************************************
	 * PENCIL - Corrected using actual cylinder/cone origins
	 ***********************************************************/

	 // Bright yellow pencil body
	SetShaderColor(1.0f, 1.0f, 0.0f, 1.0f);
	SetShaderMaterial("paper");

	SetTransformations(
		glm::vec3(0.10f, 2.50f, 0.10f),
		0.0f, 0.0f, -90.0f,
		glm::vec3(-3.40f, 0.13f, 3.0f));

	m_basicMeshes->DrawCylinderMesh();

	// Wooden tip: base connects to right end of pencil
	SetShaderColor(0.82f, 0.60f, 0.35f, 1.0f);

	SetTransformations(
		glm::vec3(0.10f, 0.35f, 0.10f),
		0.0f, 0.0f, -90.0f,
		glm::vec3(-0.90f, 0.13f, 3.0f));

	m_basicMeshes->DrawConeMesh();

	// Graphite point
	SetShaderColor(0.12f, 0.12f, 0.13f, 1.0f);

	SetTransformations(
		glm::vec3(0.035f, 0.13f, 0.035f),
		0.0f, 0.0f, -90.0f,
		glm::vec3(-0.63f, 0.13f, 3.0f));

	m_basicMeshes->DrawConeMesh();

	// Metal ferrule at left end
	SetShaderColor(0.70f, 0.70f, 0.72f, 1.0f);

	SetTransformations(
		glm::vec3(0.115f, 0.20f, 0.115f),
		0.0f, 0.0f, -90.0f,
		glm::vec3(-3.60f, 0.13f, 3.0f));

	m_basicMeshes->DrawCylinderMesh();

	// Pink eraser attached to the ferrule
	SetShaderColor(0.95f, 0.35f, 0.50f, 1.0f);

	SetTransformations(
		glm::vec3(0.105f, 0.22f, 0.105f),
		0.0f, 0.0f, -90.0f,
		glm::vec3(-3.82f, 0.13f, 3.0f));

	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * COFFEE MUG - Corrected body, opening, rim, and handle
	 ***********************************************************/

	 // Pink mug body
	SetShaderColor(0.79f, 0.27f, 0.44f, 1.0f);
	SetShaderMaterial("cover");

	SetTransformations(
		glm::vec3(0.85f, 1.20f, 0.85f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-4.60f, 0.05f, -0.55f));

	m_basicMeshes->DrawCylinderMesh();

	// Dark top creates the appearance of a mug opening
	SetShaderColor(0.10f, 0.055f, 0.045f, 1.0f);

	SetTransformations(
		glm::vec3(0.72f, 0.025f, 0.72f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-4.60f, 1.255f, -0.55f));

	m_basicMeshes->DrawCylinderMesh(true, false, false);

	// Rounded pink rim lying horizontally
	SetShaderColor(0.90f, 0.38f, 0.55f, 1.0f);

	SetTransformations(
		glm::vec3(0.80f, 0.80f, 0.10f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(-4.60f, 1.26f, -0.55f));

	m_basicMeshes->DrawTorusMesh();

	// Handle extends to the left of the mug
	SetShaderColor(0.90f, 0.38f, 0.55f, 1.0f);

	SetTransformations(
		glm::vec3(0.50f, 0.50f, 0.12f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-5.65f, 0.70f, -0.55f));

	m_basicMeshes->DrawTorusMesh();
}
